This is my package from 7 modul Python Developer course in GoIT
